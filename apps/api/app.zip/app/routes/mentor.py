from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from groq import Groq
import os
from dotenv import load_dotenv

load_dotenv()

router = APIRouter(
    prefix="/api/mentor",
    tags=["Mentor"]
)

client = Groq(
    api_key=os.getenv("GROQ_API_KEY")
)


class ChatRequest(BaseModel):
    message: str


class ChatResponse(BaseModel):
    response: str


@router.post("/chat", response_model=ChatResponse)
async def mentor_chat(req: ChatRequest):
    try:
        completion = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[
                {
                    "role": "system",
                    "content": """
You are SARTHI, the AI Digital Mentor of COSMOS.

Your role is to guide learners in:

- skill improvement
- roadmap planning
- project suggestions
- interview preparation
- resume strengthening
- career decision making

Rules:
- Answer clearly
- Keep answers practical
- Suggest actionable next steps
- If user asks technical questions, explain step-by-step
- Focus on student growth and competency improvement
"""
                },
                {
                    "role": "user",
                    "content": req.message
                }
            ],
            temperature=0.7,
            max_tokens=800
        )

        
        reply = completion.choices[0].message.content.replace("\\n", "\n")


        return ChatResponse(response=reply)

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Groq API Error: {str(e)}"
        )
